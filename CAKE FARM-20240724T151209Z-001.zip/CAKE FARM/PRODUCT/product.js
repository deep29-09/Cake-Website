// product.js

// Initialize an empty cart array
let cart = [];

// Function to add a product to the cart
function addToCart(productName, productPrice) {
    const item = {
        name: productName,
        price: productPrice
    };
    
    cart.push(item);
    updateCartUI();
}

// Function to update the cart user interface
function updateCartUI() {
    const cartItemsList = document.querySelector(".cart-items");
    const cartTotalSpan = document.getElementById("cart-total");

    // Clear the existing cart items
    cartItemsList.innerHTML = "";
    
    // Calculate total amount and update the cart items list
    let totalAmount = 0;
    cart.forEach(item => {
        const cartItem = document.createElement("li");
        cartItem.textContent = `${item.name} - Rs ${item.price}`;
        cartItemsList.appendChild(cartItem);
        totalAmount += item.price;
    });

    // Calculate GST and total including GST
    const GST_PERCENTAGE = 18;
    const GSTAmount = (totalAmount * GST_PERCENTAGE) / 100;
    const totalIncludingGST = totalAmount + GSTAmount;

    // Update the total amount in the cart
    cartTotalSpan.textContent = totalIncludingGST.toFixed(2);
}
